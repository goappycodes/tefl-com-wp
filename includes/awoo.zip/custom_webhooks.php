<?php

function flow_woocommerce_order_placed( $workflow ) {

	$order	= $workflow->data_layer()->get_order();
	// The data layer will return a valid data item or false
	if ( ! $order ) {
		return;
	}
	
    $order_id   = $order->get_id();
    $workflow_id = $workflow->id;

    $default_zap_id = 'bvcc6xv';

	pt_custom_log( $response, 'autowebhook' );
	pt_custom_log( "workflow ID: ".$workflow_id, 'autowebhook' );
    prepare_and_deliver_webhook($order_id, $default_zap_id, false, $workflow_id);
		
}

function prepare_and_deliver_webhook($order_id, $default_zap_id, $debug = false, $workflow_id = false ){

    $order      = wc_get_order($order_id);
    if ( !$order_id || !$order || !$default_zap_id ) {
        die('No order or flow or zap ID specified');
    }

  	$zap_id = get_field('workflow_zapier_id', $workflow_id);
    $zap_id = $zap_id ? $zap_id : $default_zap_id;
    $url = "https://hooks.zapier.com/hooks/catch/799242/$zap_id/";

    $response = zoho_deliver_webhook($order_id, $url, $debug);
    pt_custom_log( $response, 'autowebhook' );

    return $response;    
}

function zoho_deliver_webhook($order_id, $webhook_url, $debug = false){

    $WC_Session_Handler = new WC_Session_Handler();
    $WC_Session_Handler->init_session_cookie();
    
    $order = wc_get_order($order_id);
    $customer_id = 6304;
    // This is Prz user ID
    
    wp_set_current_user( $customer_id );
    wp_set_auth_cookie( $customer_id, true );
  

    $order_data = wc()->api->get_endpoint_data( "/wc/v3/orders/{$order_id}" );
    $line_items = isset($order_data['line_items']) ? $order_data['line_items'] : [];
    $product_ids = $product_names = $variation_ids = [];

    foreach ($line_items as $line_item){
        $product_ids[]      = isset($line_item['product_id']) ? $line_item['product_id'] : '';
        $product_names[]    = isset($line_item['name']) ? $line_item['name'] : '';
        $variation_ids[]    = isset($line_item['variation_id']) ? $line_item['variation_id'] : '';
    }

    $order_data['product_ids']      = implode(",", $product_ids);
    $order_data['product_names']    = implode(",", $product_names);
    $order_data['variation_ids']    = implode(",", $variation_ids);

    $course_date = get_course_date_from_order($order);
    if ($course_date){
        $order_data['course_start_date']    = $course_date;

        $order_data['joining__info']        = get_merge_value_from_course_date($course_date, 'joining__info');
        $order_data['instructor_bio']       = get_merge_value_from_course_date($course_date, 'instructor_bio');
        $order_data['course_date__info']    = get_merge_value_from_course_date($course_date, 'course_date__info');

        $order_data['instructor_name']      = get_merge_value_from_course_date($course_date, 'instructor_name');
        $order_data['course_date_text']     = get_merge_value_from_course_date($course_date, 'course_date_text');
        $order_data['course_time_text']     = get_merge_value_from_course_date($course_date, 'course_time_text');
    }


    // unset($order_data['_links']);

    $response = [];
    
    if ($debug){
        print_r(json_encode($order_data));
        die();
    } else {
        // $order_json = json_encode($order_data);
        $response = wp_remote_post( $webhook_url, array(
            'body'    => $order_data,
        ) );
    }


    return $response;
}


